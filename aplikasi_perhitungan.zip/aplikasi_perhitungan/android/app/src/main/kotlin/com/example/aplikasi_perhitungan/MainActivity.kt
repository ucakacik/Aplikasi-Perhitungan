package com.example.aplikasi_perhitungan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
